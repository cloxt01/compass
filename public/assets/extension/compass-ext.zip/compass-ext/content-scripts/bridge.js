// content-scripts/bridge.js
// Isolated world - terima postMessage dari interceptor.js, terusin ke background

window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.source !== "compass-token-interceptor") return;

    const {provider, payload} = event.data;

    if (payload) {
        chrome.runtime.sendMessage({
            type: "TOKEN_FROM_PAGE",
            provider,
            token: payload,
        });
    }
});