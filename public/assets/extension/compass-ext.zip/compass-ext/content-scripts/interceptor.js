// content-scripts/interceptor.js
(function () {
    const TARGETS = [
        {
            provider: "jobstreet",
            patterns: [
                "login.seek.com/oauth/token",
                "id.jobstreet.com/oauth/token",
            ],
        },
        {
            provider: "glints",
            patterns: [
                "glints.com/api/oauth2/token",
            ],
        },
    ];

    function getTarget(url) {
        return TARGETS.find((target) =>
            target.patterns.some((pattern) => url.includes(pattern))
        );
    }

    // ==========================
    // Fetch interception
    // ==========================

    const originalFetch = window.fetch;

    window.fetch = async function (...args) {
        const response = await originalFetch.apply(this, args);

        const url =
            typeof args[0] === "string"
                ? args[0]
                : args[0]?.url || "";

        const target = getTarget(url);

        if (!target) {
            return response;
        }

        console.log("[Compass] Matched Fetch:", target.provider, url);

        response
            .clone()
            .json()
            .then((data) => {
                window.postMessage(
                    {
                        source: "compass-token-interceptor",
                        provider: target.provider,
                        payload: data,
                    },
                    "*"
                );
            })
            .catch(() => {
                // Response bukan JSON
            });

        return response;
    };

    // ==========================
    // XMLHttpRequest interception
    // ==========================

    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this.__compassUrl = url;
        return originalOpen.call(this, method, url, ...rest);
    };

    XMLHttpRequest.prototype.send = function (...args) {
        this.addEventListener("load", function () {
            const target = getTarget(this.__compassUrl || "");

            if (!target) {
                return;
            }

            console.log("[Compass] Matched XHR:", target.provider, this.__compassUrl);

            try {
                const data = JSON.parse(this.responseText);

                window.postMessage(
                    {
                        source: "compass-token-interceptor",
                        provider: target.provider,
                        payload: data,
                    },
                    "*"
                );
            } catch (e) {
                // Response bukan JSON
            }
        });

        return originalSend.apply(this, args);
    };
})();