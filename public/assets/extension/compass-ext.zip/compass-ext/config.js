// config.js
// Centralized configuration for Compass Token Grabber extension

const ExtensionConfig = {
  // Debug settings
  DEBUG_MODE: true, // Set to false sebelum rilis production

  // Extension metadata
  EXTENSION_NAME: "CompassTokenGrabber",
  VERSION: "1.0.0",

  // Performance settings
  TOKEN_CAPTURE_DELAY: 1000, // ms - delay sebelum stop listening setelah token captured
  PAGE_RELOAD_DEBOUNCE: 100, // ms - debounce untuk deteksi reload halaman

  // UI settings
  STATUS_TIMEOUT: 2000, // ms - default timeout status message
  COPY_FEEDBACK_TIMEOUT: 1600, // ms - timeout feedback tombol copy

  // Target providers yang mau di-capture tokennya
  // PROVIDERS: {
  //   jobstreet: {
  //     label: "JobStreet",
  //     storageKey: "jobstreet_token",
  //     urlPatterns: "https://login.seek.com/oauth/token*",
  //     captureMethod: "body",
  //   },
  //   glints: {
  //     label: "Glints",
  //     urlPatterns: ["https://glints.com/api/oauth2/token*"],
  //     storageKey: "glints_token",
  //     captureMethod: "body",
  //   },
  // },
  COMPASS_HOST: "https://cloxt.tech",
  PROVIDERS: {
    jobstreet: {
      label: "JobStreet",
      storageKey: "jobstreet_token",
      captureMethod: "body",
      urlPatterns: [
          "https://login.seek.com/oauth/token*"
      ],
      tokenUrls: [
        "login.seek.com/oauth/token",
        "id.jobstreet.com/oauth/token",
      ],
    },
    glints: {
      label: "Glints",
      storageKey: "glints_token",
      captureMethod: "body",
      urlPatterns: [
          "https://glints.com/api/oauth2/token*"
      ],
      tokenUrls: [
        "glints.com/api/oauth2/token",
      ]
    }
  },

  // Compass API sync settings
  COMPASS_API_BASE: "https://cloxt.tech/api",
  COMPASS_SYNC_ENDPOINT: "/tokens/grab",
  AUTO_SYNC_DEFAULT: false, // default value kalau user belum set di options
};

// Debug logging helper function
function debugLog(level, context, message, ...args) {
  if (ExtensionConfig.DEBUG_MODE) {
    const contextSuffix = context ? `-${context}` : "";
    const prefix = `[${ExtensionConfig.EXTENSION_NAME}${contextSuffix}]`;
    console[level](prefix, message, ...args);
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { ExtensionConfig, debugLog };
} else {
  let globalScope;
  if (typeof self !== "undefined") globalScope = self;
  else if (typeof window !== "undefined") globalScope = window;
  else globalScope = {};

  globalScope.ExtensionConfig = ExtensionConfig;
  globalScope.debugLog = debugLog;
}