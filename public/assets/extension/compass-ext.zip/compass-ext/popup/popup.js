// popup/popup.js
// UI untuk menampilkan status capture token JobStreet & Glints

const providerListEl = document.getElementById("providerList");
const toggleBtn = document.getElementById("toggleBtn");
const listeningStatusEl = document.getElementById("listeningStatus");
const clearBtn = document.getElementById("clearBtn");
const versionLabel = document.getElementById("versionLabel");
const optionsLink = document.getElementById("optionsLink");
const tokenCountEl = document.getElementById("tokenCount");

let currentTokens = {};
let isListening = false;
let statusTimeout = null;
let syncStatusTimeout = null;
const copyTimeouts = {}; // per-provider, biar copy provider A gak reset tombol provider B

// ---- debugLog stub (provided by config.js, but safe fallback) ----
if (typeof debugLog === 'undefined') {
  window.debugLog = function(level, source, message, ...args) {
    if (level === 'error') {
      console.error(`[${source}] ${message}`, ...args);
    } else {
      console.log(`[${source}] ${message}`, ...args);
    }
  };
}

function log(level, message, ...args) {
  debugLog(level, "Popup", message, ...args);
}

function cleanup() {
  if (statusTimeout) {
    clearTimeout(statusTimeout);
    statusTimeout = null;
  }
  if (syncStatusTimeout) {
    clearTimeout(syncStatusTimeout);
    syncStatusTimeout = null;
  }
  Object.values(copyTimeouts).forEach(clearTimeout);
}

function sendMessage(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, resolve);
  });
}

function setStatus(msg, timeout) {
  const t = timeout || (typeof ExtensionConfig !== 'undefined' ? ExtensionConfig.STATUS_TIMEOUT : 3000);
  if (statusTimeout) {
    clearTimeout(statusTimeout);
    statusTimeout = null;
  }
  listeningStatusEl.textContent = msg;
  if (t) {
    statusTimeout = setTimeout(() => {
      if (listeningStatusEl.textContent === msg) {
        listeningStatusEl.textContent = isListening ? "Listening..." : "Idle";
      }
      statusTimeout = null;
    }, t);
  }
}

function updateToggleUI(listening) {
  isListening = listening;
  toggleBtn.textContent = listening ? "Stop Capture" : "Start Capture";
  listeningStatusEl.textContent = listening ? "Listening..." : "Idle";
  listeningStatusEl.className = listening ? "listening-active" : "";
  // Update dot
  const dot = document.getElementById('statusDot');
  if (dot) {
    dot.className = 'dot ' + (listening ? 'active' : 'idle');
  }
}

function updateTokenCount() {
  if (!tokenCountEl) return;
  const count = Object.values(ExtensionConfig.PROVIDERS).filter(
      (p) => !!currentTokens[p.storageKey]
  ).length;
  tokenCountEl.textContent = `${count} token${count !== 1 ? 's' : ''}`;
}

function renderProviderRows() {
  providerListEl.innerHTML = "";

  for (const [key, provider] of Object.entries(ExtensionConfig.PROVIDERS)) {

    const token = currentTokens[provider.storageKey];
    const captured = !!token;

    const row = document.createElement("div");
    row.className = "provider-row";

    const iconLetter = provider.label.charAt(0).toUpperCase();

    row.innerHTML = `
        <span class="provider-icon">${iconLetter}</span>

        <div style="flex:1">
            <div class="provider-label">${provider.label}</div>
            <div class="provider-status ${captured ? "ok" : "no"}">
                ${captured ? "Captured" : "Not Captured"}
            </div>
        </div>

        ${
        captured
            ? `<button
                    class="connect-btn btn-secondary"
                    data-provider="${key}">
                    Hubungkan
               </button>`
            : ""
    }

        <button
            class="copy-btn"
            data-provider="${key}"
            ${captured ? "" : "disabled"}>
            Copy
        </button>
    `;

    providerListEl.appendChild(row);
  }

  providerListEl
      .querySelectorAll(".copy-btn")
      .forEach(btn =>
          btn.addEventListener("click",
              () => copyProviderToken(btn.dataset.provider))
      );

  providerListEl
      .querySelectorAll(".connect-btn")
      .forEach(btn =>
          btn.addEventListener("click",
              () => connectProvider(btn.dataset.provider))
      );

  updateTokenCount();
}
function formatTime(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour12: false });
}

async function copyProviderToken(providerKey) {
  const provider = ExtensionConfig.PROVIDERS[providerKey];
  const value = JSON.stringify(currentTokens[provider.storageKey]);
  if (!value) return;

  try {
    await navigator.clipboard.writeText(value);
    const btn = providerListEl.querySelector(`.copy-btn[data-provider="${providerKey}"]`);
    if (btn) {
      btn.classList.add("copy-ok");
      btn.textContent = "Copied!";
    }
    setStatus(`${provider.label} token disalin`);

    if (copyTimeouts[providerKey]) clearTimeout(copyTimeouts[providerKey]);
    const timeout = typeof ExtensionConfig !== 'undefined' ? ExtensionConfig.COPY_FEEDBACK_TIMEOUT : 1500;
    copyTimeouts[providerKey] = setTimeout(() => {
      if (btn) {
        btn.classList.remove("copy-ok");
        btn.textContent = "Copy";
      }
      copyTimeouts[providerKey] = null;
    }, timeout);
  } catch (e) {
    log("error", "Copy failed:", e);
    setStatus("Copy gagal");
  }
}

async function loadTokenStatus() {
  try {
    const res = await sendMessage({ type: "getTokenStatus" });
    currentTokens = res?.tokens || {};
    renderProviderRows();
  } catch (e) {
    log("error", "Load token status failed:", e);
    setStatus("Error loading");
  }
}

async function loadListeningState() {
  try {
    const result = await chrome.storage.session.get("isListening");
    updateToggleUI(!!result.isListening);
  } catch (e) {
    log("error", "Load listening state failed:", e);
  }
}

async function handleToggle() {
  const messageType = isListening ? "stopListening" : "startListening";
  try {
    const res = await sendMessage({ type: messageType });
    if (res?.success) {
      updateToggleUI(res.listening);

      if (res.listening) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs.length > 0 && tabs[0].url) {
            try {
              const url = new URL(tabs[0].url);
              setStatus(`Listening dari ${url.hostname}...`, 3000);
            } catch (_) {
              setStatus("Listening aktif...", 3000);
            }
          } else {
            setStatus("Listening aktif...", 3000);
          }
        });
      }
    }
  } catch (e) {
    log("error", "Toggle listening failed:", e);
    setStatus("Gagal toggle listening");
  }
}

async function connectProvider(provider) {

  const config = ExtensionConfig.PROVIDERS[provider];
  const token = currentTokens[config.storageKey];

  if (!token) {
    setStatus("Token belum tersedia");
    return;
  }

  const url = new URL(
      `${ExtensionConfig.COMPASS_HOST}/connection/${provider}/connect`
  );

  url.searchParams.set("access_token", token.access_token);
  url.searchParams.set("refresh_token", token.refresh_token);
  url.searchParams.set("expires_in", token.expires_in);

  chrome.tabs.create({
    url: url.toString()
  });
}
async function handleClear() {
  try {
    await sendMessage({ type: "clearCapturedData" });
    currentTokens = {};
    renderProviderRows();
    setStatus("Semua token dihapus", 2000);
  } catch (e) {
    log("error", "Clear failed:", e);
    setStatus("Gagal clear data");
  }
}

// ---- Event listeners ----
toggleBtn.addEventListener("click", handleToggle);
clearBtn.addEventListener("click", handleClear);
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  if (chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    window.open(chrome.runtime.getURL('options.html'));
  }
});

// ---- Cleanup on unload ----
window.addEventListener("beforeunload", () => {
  cleanup();
  // NOTE: TIDAK auto-stop listening di sini, beda dari versi single-header asli,
  // karena capture Compass butuh tetap jalan di background walau popup ditutup
  // (user buka jobstreet, popup ketutup otomatis, listener tetep harus aktif).
});

// ---- Real-time update dari background script ----
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "tokenCaptured") {
    const provider = ExtensionConfig.PROVIDERS[message.provider];
    setStatus(`${provider?.label || message.provider} token tertangkap!`, 3000);
    loadTokenStatus();
    sendResponse({ received: true });
  } else if (message.type === "pageReloaded") {
    if (message.url) {
      try {
        const url = new URL(message.url);
        setStatus(`Halaman reload - listening dari ${url.hostname}...`, 3000);
      } catch (_) {
        setStatus("Halaman reload - listening...", 3000);
      }
    } else {
      setStatus("Halaman reload - listening...", 3000);
    }
    sendResponse({ received: true });
  } else if (message.type === "tabChanged") {
    if (message.url) {
      try {
        const url = new URL(message.url);
        setStatus(`Pindah ke ${url.hostname} - listening...`, 3000);
      } catch (_) {
        setStatus("Pindah tab - listening...", 3000);
      }
    } else {
      setStatus("Pindah tab - listening...", 3000);
    }
    sendResponse({ received: true });
  }
  return true; // keep channel open for async response
});

// ---- Initial load ----
(async function init() {
  // Version
  if (typeof ExtensionConfig !== 'undefined' && ExtensionConfig.VERSION) {
    versionLabel.textContent = ExtensionConfig.VERSION;
  } else {
    versionLabel.textContent = '1.0';
  }

  await loadTokenStatus();
  await loadListeningState();
})();