// bg/background.js
importScripts("../config.js");

const STORAGE_KEYS = {
  ACTIVE_TAB: "activeTabId",
  LISTENING: "isListening",
};

function log(level, message, ...args) {
  debugLog(level, "Background", message, ...args);
}

let activeTabId = null;
let isListening = false;
let tabUpdateListener = null;
let tabActivationListener = null;
let pageReloadTimeout = null;
let lastStoredTabId = null;

const HEADER_PROVIDERS = Object.entries(ExtensionConfig.PROVIDERS)
    .filter(([, p]) => p.captureMethod === "header");

const BODY_PROVIDERS = Object.entries(ExtensionConfig.PROVIDERS)
    .filter(([, p]) => p.captureMethod === "body");

const BODY_PROVIDER_MAP = Object.fromEntries(BODY_PROVIDERS);

function cleanup() {
  if (pageReloadTimeout) {
    clearTimeout(pageReloadTimeout);
    pageReloadTimeout = null;
  }
  if (tabUpdateListener && chrome.tabs.onUpdated.hasListener(tabUpdateListener)) {
    chrome.tabs.onUpdated.removeListener(tabUpdateListener);
    tabUpdateListener = null;
  }
  if (tabActivationListener && chrome.tabs.onActivated.hasListener(tabActivationListener)) {
    chrome.tabs.onActivated.removeListener(tabActivationListener);
    tabActivationListener = null;
  }
  lastStoredTabId = null;
}

async function getSession(keys) {
  return new Promise((resolve) => chrome.storage.session.get(keys, resolve));
}
async function setSession(obj) {
  return new Promise((resolve) => chrome.storage.session.set(obj, resolve));
}

async function startListening() {
  if (isListening) return;

  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length === 0) return;

    activeTabId = tabs[0].id;
    isListening = true;

    await setSession({
      [STORAGE_KEYS.ACTIVE_TAB]: activeTabId,
      [STORAGE_KEYS.LISTENING]: true,
    });

    addTabUpdateListener();
    addTabActivationListener();
    log("log", "Started listening on tab", activeTabId);
  } catch (error) {
    log("error", "Failed to start listening:", error);
  }
}

async function stopListening() {
  if (!isListening) return;
  isListening = false;
  activeTabId = null;
  cleanup();
  await setSession({
    [STORAGE_KEYS.LISTENING]: false,
    [STORAGE_KEYS.ACTIVE_TAB]: null,
  });
  log("log", "Stopped listening");
}

async function handlePageReload(tabId) {
  if (activeTabId === tabId || !isListening) {
    if (pageReloadTimeout) clearTimeout(pageReloadTimeout);
    pageReloadTimeout = setTimeout(async () => {
      if (!isListening) await startListening();
      pageReloadTimeout = null;
    }, ExtensionConfig.PAGE_RELOAD_DEBOUNCE);
  }
}

function addTabUpdateListener() {
  if (tabUpdateListener || !isListening) return;

  tabUpdateListener = async (tabId, changeInfo, tab) => {
    if (changeInfo.status !== "loading" || !tab.url || !isListening) return;
    if (activeTabId && tabId !== activeTabId) return;

    try {
      if (!activeTabId) {
        const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (activeTabs.length === 0 || activeTabs[0].id !== tabId) return;
        activeTabId = tabId;
      }
      if (lastStoredTabId !== activeTabId) {
        await setSession({ [STORAGE_KEYS.ACTIVE_TAB]: activeTabId });
        lastStoredTabId = activeTabId;
      }
    } catch (error) {
      log("error", "Error checking active tab:", error);
      return;
    }

    try {
      await handlePageReload(tabId);
      chrome.runtime
          .sendMessage({ type: "pageReloaded", tabId, url: tab.url })
          .catch(() => {});
    } catch (error) {
      log("error", "Error handling page reload:", error);
    }
  };

  chrome.tabs.onUpdated.addListener(tabUpdateListener);
}

function addTabActivationListener() {
  if (tabActivationListener || !isListening) return;

  tabActivationListener = async (activeInfo) => {
    if (isListening && activeInfo.tabId !== activeTabId) {
      activeTabId = activeInfo.tabId;
      if (lastStoredTabId !== activeTabId) {
        await setSession({ [STORAGE_KEYS.ACTIVE_TAB]: activeTabId });
        lastStoredTabId = activeTabId;
      }
      try {
        const tab = await chrome.tabs.get(activeTabId);
        chrome.runtime
            .sendMessage({ type: "tabChanged", tabId: activeTabId, url: tab.url })
            .catch(() => {});
      } catch (error) {
        log("warn", "Tab no longer exists:", error.message);
      }
    }
  };

  chrome.tabs.onActivated.addListener(tabActivationListener);
}

(async () => {
  const data = await getSession(Object.values(STORAGE_KEYS));
  const sets = {};
  if (data[STORAGE_KEYS.LISTENING] === undefined) sets[STORAGE_KEYS.LISTENING] = false;
  if (Object.keys(sets).length) await setSession(sets);
})();

// Simpan token (dipakai baik dari header capture maupun dari response-body capture)
async function saveToken(providerKey, storageKey, value) {
  const { [storageKey]: existing } = await chrome.storage.local.get(storageKey);
  const same =
      typeof value === "object"
          ? JSON.stringify(existing) === JSON.stringify(value)
          : existing === value;

  if (same) return;

  await chrome.storage.local.set({
    [storageKey]: value,
    [`${storageKey}_captured_at`]: new Date().toISOString(),
  });

  log("log", `[${providerKey}] token saved`);

  chrome.runtime
      .sendMessage({
        type: "tokenCaptured",
        provider: providerKey,
        timestamp: Date.now(),
      })
      .catch(() => {});

  maybeAutoSync();
  await checkAllCapturedAndMaybeStop();
}

async function checkAllCapturedAndMaybeStop() {
  const allKeys = Object.values(ExtensionConfig.PROVIDERS).map((p) => p.storageKey);
  const allTokens = await chrome.storage.local.get(allKeys);
  const allCaptured = allKeys.every((k) => !!allTokens[k]);

  if (allCaptured && isListening) {
    setTimeout(async () => {
      await stopListening();
    }, ExtensionConfig.TOKEN_CAPTURE_DELAY);
  }
}

// Hanya provider dengan captureMethod "header" yang perlu di-listen via webRequest
const HEADER_BASED_PROVIDERS = Object.entries(ExtensionConfig.PROVIDERS)
    .filter(([, provider]) => provider.captureMethod === "header");

// 2. Kumpulkan URL patterns dari provider header (fallback [] jika undefined)
const HEADER_BASED_URLS = HEADER_PROVIDERS.flatMap(
    ([, p]) => p.urlPatterns || []
);


// 3. Fungsi pencocokan – aman meskipun tidak ada provider header
function matchProvider(url) {
  for (const [key, provider] of HEADER_PROVIDERS) {
    for (const pattern of (provider.urlPatterns || [])) {
      const regex = new RegExp("^" + pattern.replace(/\*/g, ".*") + "$");

      if (regex.test(url)) {
        return { key, provider };
      }
    }
  }

  return null;
}
// 4. Daftarkan listener HANYA jika ada URL pattern
if (HEADER_BASED_URLS.length > 0) {
  chrome.webRequest.onBeforeSendHeaders.addListener(
      async (details) => {
        if (!isListening) return;
        if (!activeTabId || details.tabId !== activeTabId) return;

        const match = matchProvider(details.url);
        if (!match) return; // tetap aman

        const authHeader = details.requestHeaders?.find(
            (h) => h.name.toLowerCase() === "authorization"
        );
        if (!authHeader) {
          log("log", `[${match.key}] no Authorization header on`, details.url);
          return;
        }

        await saveToken(match.key, match.provider.storageKey, authHeader.value);
      },
      { urls: HEADER_BASED_URLS }, // langsung pakai array yang sudah valid
      ["requestHeaders", "extraHeaders"]
  );

  log("log", `Listener webRequest dipasang untuk ${HEADER_BASED_URLS.length} URL pattern`);
} else {
  log("log", "Tidak ada provider dengan captureMethod 'header', listener tidak dibuat.");
}
async function maybeAutoSync() {
  const { auto_sync, api_key } = await chrome.storage.local.get(["auto_sync", "api_key"]);
  if (!auto_sync || !api_key) return;
  await syncToCompass(api_key);
}

async function syncToCompass(api_key) {
  const keys = Object.values(ExtensionConfig.PROVIDERS).map((p) => p.storageKey);
  const tokens = await chrome.storage.local.get(keys);

  try {
    const res = await fetch(
        `${ExtensionConfig.COMPASS_API_BASE}${ExtensionConfig.COMPASS_SYNC_ENDPOINT}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-API-Key": api_key },
          body: JSON.stringify(tokens),
        }
    );
    if (!res.ok) throw new Error(`Sync failed: ${res.status}`);
    log("log", "Sync berhasil");
  } catch (e) {
    log("error", "Sync gagal:", e);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message?.type) {
      case "startListening": {
        await startListening();
        sendResponse({ success: true, listening: isListening });
        break;
      }
      case "stopListening": {
        await stopListening();
        sendResponse({ success: true, listening: isListening });
        break;
      }
      case "clearCapturedData": {
        const keys = Object.values(ExtensionConfig.PROVIDERS).map((p) => p.storageKey);
        const clearObj = {};
        keys.forEach((k) => {
          clearObj[k] = null;
          clearObj[`${k}_captured_at`] = null;
        });
        await chrome.storage.local.set(clearObj);
        sendResponse({ success: true, cleared: true });
        break;
      }
      case "getTokenStatus": {
        const keys = Object.values(ExtensionConfig.PROVIDERS).map((p) => p.storageKey);
        const data = await chrome.storage.local.get(keys);
        sendResponse({ tokens: data });
        break;
      }
      case "syncNow": {
        const { api_key } = await chrome.storage.local.get("api_key");
        if (!api_key) {
          sendResponse({ success: false, error: "API key belum diset" });
          break;
        }
        await syncToCompass(api_key);
        sendResponse({ success: true });
        break;
      }
        // Capture via response body (kasus JobStreet: token ada di response
        // endpoint oauth/token, bukan di request header, jadi dikirim dari
        // content-scripts/bridge.js lewat window.postMessage -> sendMessage)
      case "TOKEN_FROM_PAGE": {
        const provider = BODY_PROVIDER_MAP[message.provider];

        if (!provider) {
          sendResponse({
            success: false,
            error: "Unknown body provider",
          });
          break;
        }

        await saveToken(
            message.provider,
            provider.storageKey,
            message.token
        );

        sendResponse({ success: true });
        break;
      }
      default:
        sendResponse({ error: "Unknown message type" });
    }
  })();
  return true;
});

chrome.runtime.onSuspend.addListener(() => cleanup());
chrome.runtime.onStartup.addListener(() => cleanup());