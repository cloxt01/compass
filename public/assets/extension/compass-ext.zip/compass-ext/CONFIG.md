# Extension Configuration Guide

## Debug Mode Configuration

The extension uses a centralized configuration system located in `config.js`.

### Development Mode (Debug ON)

```javascript
// In config.js
const ExtensionConfig = {
  DEBUG_MODE: true, // Enable debug logging
  // ... other settings
};
```

### Production Mode (Debug OFF)

```javascript
// In config.js
const ExtensionConfig = {
  DEBUG_MODE: false, // Disable debug logging
  // ... other settings
};
```

## Configuration Options

| Setting                 | Default | Description                                              |
| ----------------------- | ------- | -------------------------------------------------------- |
| `DEBUG_MODE`            | `true`  | Enable/disable console logging                           |
| `TOKEN_CAPTURE_DELAY`   | `1000`  | Delay (ms) before stopping listening after token capture |
| `PAGE_RELOAD_DEBOUNCE`  | `100`   | Debounce (ms) for page reload detection                  |
| `STATUS_TIMEOUT`        | `2000`  | Default timeout (ms) for status messages                 |
| `COPY_FEEDBACK_TIMEOUT` | `1600`  | Timeout (ms) for copy button feedback                    |

## Quick Setup for Chrome Web Store

### 1. Set Production Mode

Edit `config.js`:

```javascript
DEBUG_MODE: false, // Disable all console logs
```

### 2. Test Extension

- Load the extension in Chrome
- Test all functionality
- Verify no console logs appear

### 3. Package for Store

- Zip the extension folder
- Submit to Chrome Web Store

### 4. Restore Development Mode (optional)

Edit `config.js`:

```javascript
DEBUG_MODE: true, // Re-enable logs for future development
```

## Log Format

When `DEBUG_MODE: true`, logs appear as:

- Background script: `[GetAuthHeader-Background] message`
- Popup script: `[GetAuthHeader-Popup] message`

When `DEBUG_MODE: false`, no logs are produced.
