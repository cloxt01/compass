<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
    Schema::create('jobstreet_accounts', function (Blueprint $table) {
        $table->id();

        $table->foreignId('user_id')
            ->constrained()
            ->cascadeOnDelete()
            ->unique();

        $table->text('access_token');
        $table->text('refresh_token')->nullable();
        $table->timestamp('expired_at')->nullable();
        $table->string('status')->default('active');
        $table->json('apply_configuration')->nullable();
        $table->timestamps();
    });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {

    }
};
