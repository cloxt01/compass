<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('otps', function (Blueprint $table) {
            $table->id();
            $table->string('user_id');
            $table->string('uuid');
            $table->string('otp', 8);
            $table->boolean('consumed')->default(false);

            $table->timestamps();

            // index buat polling cepat
            $table->index(['user_id', 'consumed']);
        });

       
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('otps');
    }
};
